import { useEffect, useState, type ReactNode } from "react";
import { useNavigate, useParams } from "react-router-dom";
import PageLayout from "../components/layout/PageLayout";
import LearnCard from "../components/lesson/LearnCard";
import LessonHero from "../components/lesson/LessonHero";
import PracticeTimeCard from "../components/lesson/PracticeTimeCard";
import TryItCard from "../components/lesson/TryItCard";
import WarmUpCard from "../components/lesson/WarmUpCard";
import { getLessonById } from "../lib/lessonLookup";
import { getFlashcardDeckCardIds } from "../flashcards/deckRegistry";
import {
  useStudentProgress,
  type LessonProgress,
  type LessonPracticeRewardState,
  type FlashcardDeckProgress,
} from "../contexts/StudentProgressContext";
import type { WarmUpData } from "../types/warmup";
import { getLessonExperience } from "../data/lessonExperience";
import { getChapterForConcept, getConceptByLessonId } from "../data/curriculum/curriculumGraph";

type LessonWithStructuredData = {
  warmup?: WarmUpData;
};

type SectionState = "complete" | "active" | "future";

type NextLessonStep = {
  title: string;
  description: string;
  buttonLabel: string;
  to: string;
};

function getNextStep({
  lessonId,
  nextLessonId,
  progress,
  getPracticeRewardState: getRewards,
  getFlashcardDeckProgress: getDeckProgress,
  flashcardDeckId,
  flashcardCardIds,
}: {
  lessonId: string;
  nextLessonId?: string;
  progress: LessonProgress;
  getPracticeRewardState: (lessonId: string) => LessonPracticeRewardState;
  getFlashcardDeckProgress: (deckId: string, cardIds: string[]) => FlashcardDeckProgress;
  flashcardDeckId: string;
  flashcardCardIds: string[];
}): NextLessonStep {
  const practiceRewards = getRewards(lessonId);
  const guidedComplete = practiceRewards.guided?.completed === true || progress.practiceComplete;
  const independentComplete = practiceRewards.independent?.completed === true;
  const challengeComplete = practiceRewards.challenge?.completed === true;

  const flashcardProgress = getDeckProgress(flashcardDeckId, flashcardCardIds);

  if (!progress.warmupComplete) {
    return {
      title: "Warm-Up",
      description: "Start with quick review before today’s lesson.",
      buttonLabel: "Start Warm-Up ›",
      to: `/learn/${lessonId}?step=warmup`,
    };
  }

  if (!progress.learnComplete) {
    return {
      title: "Learn",
      description: "Watch the short lesson and learn today’s skill.",
      buttonLabel: "Continue Lesson ›",
      to: `/learn/${lessonId}?step=learn`,
    };
  }

  if (!progress.tryItComplete) {
    return {
      title: "Try It",
      description: "Try one guided problem before practice.",
      buttonLabel: "Start Try It ›",
      to: `/try-it/${lessonId}`,
    };
  }

  if (!guidedComplete) {
    return {
      title: "Guided Practice",
      description: "Solve step-by-step problems with hints.",
      buttonLabel: "Start Guided Practice ›",
      to: `/practice/${lessonId}?mode=guided`,
    };
  }

  if (!independentComplete) {
    return {
      title: "Independent Practice",
      description: "Show what you can do on your own.",
      buttonLabel: "Start Independent Practice ›",
      to: `/practice/${lessonId}?mode=independent`,
    };
  }

  if (!challengeComplete) {
    return {
      title: "Challenge",
      description: "Try a tougher version for an epic reward.",
      buttonLabel: "Try Challenge ›",
      to: `/practice/${lessonId}?mode=challenge`,
    };
  }

  if (!flashcardProgress.completed) {
    return {
      title: "Flashcards",
      description: "Review this lesson’s deck and strengthen recall.",
      buttonLabel: "Try Flashcards ›",
      to: `/flashcards/deck/${flashcardDeckId}`,
    };
  }

  if (nextLessonId) {
    return {
      title: "Lesson Complete",
      description: "Great work! You’re ready for the next lesson.",
      buttonLabel: "Next Lesson ›",
      to: `/lesson/${nextLessonId}`,
    };
  }

  return {
    title: "Unit Checkpoint",
    description: "Great work! Head back to the learning path.",
    buttonLabel: "Back to Learning Path ›",
    to: "/learning-path",
  };
}

function getSectionState(
  section: "warmup" | "learn" | "tryIt" | "practice",
  progress: LessonProgress,
): SectionState {
  if (section === "warmup") {
    return progress.warmupComplete ? "complete" : "active";
  }

  if (section === "learn") {
    if (progress.learnComplete) return "complete";
    return progress.warmupComplete ? "active" : "future";
  }

  if (section === "tryIt") {
    if (progress.tryItComplete) return "complete";
    return progress.learnComplete ? "active" : "future";
  }

  if (progress.practiceComplete) return "complete";
  return progress.tryItComplete ? "active" : "future";
}

// @SECTION LESSON_CARD_FRAME
function LessonCardFrame({ state, children }: { state: SectionState; children: ReactNode }) {
  const frameClass =
    state === "active"
      ? "bg-[#00AFB9] shadow-[0_0_28px_rgba(0,175,185,0.22)]"
      : state === "complete"
        ? "bg-[#00AFB9]/35"
        : "bg-transparent";

  return (
    <div className={`h-full min-h-0 rounded-[1.9rem] p-[2px] ${frameClass}`}>
      <div className="h-full min-h-0 rounded-[1.75rem]">{children}</div>
    </div>
  );
}

// @SECTION LESSON_ACTION_BAR
function LessonActionBar({ nextStep }: { nextStep: NextLessonStep }) {
  const navigate = useNavigate();

  return (
    <section
      data-name="lesson-action-bar"
      className="mb-4 rounded-[1.5rem] border border-[#073B5A]/10 bg-white px-4 py-3 shadow-sm"
    >
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-[#FFF3D9] text-xl">
          🚀
        </div>

        <div className="min-w-0 flex-1">
          <p className="text-base font-black text-[#073B5A]">
            Next Up: <span className="text-[#0081A7]">{nextStep.title}</span>
          </p>
          <p className="mt-0.5 line-clamp-1 text-[13px] font-bold text-[#073B5A]/65">
            {nextStep.description}
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate(nextStep.to)}
          className="min-h-11 shrink-0 rounded-xl bg-[#00AFB9] px-6 text-sm font-black text-white shadow-sm transition hover:bg-[#0081A7]"
        >
          {nextStep.buttonLabel}
        </button>
      </div>
    </section>
  );
}

// @SECTION LESSON_SCREEN
function LessonScreen() {
  const { lessonId } = useParams();
  const { unit, week, lesson, weekDayNumber } = getLessonById(lessonId);
  const structuredLesson = lesson as typeof lesson & LessonWithStructuredData;

  // Use context for state management
  const { getLessonProgress, getPracticeRewardState, getFlashcardDeckProgress, studentState } =
    useStudentProgress();

  // @SECTION LESSON_EXPERIENCE
  const lessonExperience = lessonId ? getLessonExperience(lessonId) : undefined;

  const currentLessonId =
    lessonId ?? `g3-u${unit.unit_number}-w${week.week_number}-l${weekDayNumber}`;

  const progress = getLessonProgress(currentLessonId);

  const [starName, setStarName] = useState(() => studentState.starProfile.starName);

  const currentStarName = studentState.starProfile.starName;

  useEffect(() => {
    // Sync starName when it changes
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setStarName(currentStarName);
  }, [currentStarName]);

  const currentWeekIndex = unit.weeks.findIndex(
    (unitWeek) => unitWeek.week_number === week.week_number,
  );
  const nextLessonInSameWeek = week.lessons[weekDayNumber];
  const nextWeek = unit.weeks[currentWeekIndex + 1];
  const nextLessonId = nextLessonInSameWeek
    ? `g3-u${unit.unit_number}-w${week.week_number}-l${weekDayNumber + 1}`
    : nextWeek
      ? `g3-u${unit.unit_number}-w${nextWeek.week_number}-l1`
      : undefined;

  const flashcardDeckId = lesson.flashcards?.deckId ?? `lesson-${currentLessonId}`;
  const flashcardCardIds = getFlashcardDeckCardIds(flashcardDeckId);

  const concept = getConceptByLessonId(currentLessonId);
  const chapter = concept ? getChapterForConcept(concept.id) : undefined;

  const nextStep = getNextStep({
    lessonId: currentLessonId,
    nextLessonId,
    progress,
    getPracticeRewardState,
    getFlashcardDeckProgress,
    flashcardDeckId,
    flashcardCardIds,
  });

  return (
    <PageLayout>
      {/* @SECTION LESSON_OVERVIEW_STACK */}
      <div data-name="lesson-overview-stack" className="flex min-h-0 flex-col">
        <LessonHero
          unitNumber={unit.unit_number}
          chapterTitle={chapter?.title}
          conceptTitle={concept?.title}
          title={lessonExperience?.title ?? lesson.lesson_title}
          topic={unit.unit_title}
          description={lessonExperience?.kidGoal ?? lesson.objective}
          minutes={lesson.lesson_type === "evaluation" ? 35 : 25}
          grade={`${unit.grade_level}rd Grade`}
          lessonType={lesson.lesson_type}
          quizQuestionCount={
            lessonExperience?.quickCheck?.questions.length ?? lesson.quiz_question_count
          }
          progress={progress}
          starName={starName}
        />

        <LessonActionBar nextStep={nextStep} />

        {/* @SECTION LESSON_STAGE_GRID */}
        <section
          data-name="lesson-stage-grid"
          className="grid min-h-0 items-stretch gap-3 lg:grid-cols-2 xl:grid-cols-[0.95fr_0.95fr_1fr_1.08fr]"
        >
          <LessonCardFrame state={getSectionState("warmup", progress)}>
            <WarmUpCard
              factDrill={lesson.fact_drill}
              warmup={structuredLesson.warmup}
              lessonId={currentLessonId}
              isComplete={progress.warmupComplete}
            />
          </LessonCardFrame>

          <LessonCardFrame state={getSectionState("learn", progress)}>
            <LearnCard
              lessonId={currentLessonId}
              concept={lesson.concept}
              isComplete={progress.learnComplete}
            />
          </LessonCardFrame>

          <LessonCardFrame state={getSectionState("tryIt", progress)}>
            <TryItCard
              lessonId={currentLessonId}
              practice={lesson.practice}
              practiceType={lesson.practice_type}
              isComplete={progress.tryItComplete}
            />
          </LessonCardFrame>

          <LessonCardFrame state={getSectionState("practice", progress)}>
            <PracticeTimeCard
              lessonId={currentLessonId}
              activities={[
                {
                  icon: "🧮",
                  title: "Guided Practice",
                  subtitle: lesson.practice,
                },
                {
                  icon: "✏️",
                  title: "Independent Practice",
                  subtitle: "Solve on your own",
                },
                {
                  icon: "🏆",
                  title: "Challenge Yourself",
                  subtitle: "Take it up a notch!",
                },
              ]}
            />
          </LessonCardFrame>
        </section>
      </div>
    </PageLayout>
  );
}

export default LessonScreen;
